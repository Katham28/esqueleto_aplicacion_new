import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'dart:typed_data';

BluetoothConnection? connection;

Future<void> connectToHC06() async {
  FlutterBluetoothSerial bluetooth = FlutterBluetoothSerial.instance;

  bool isEnabled = await bluetooth.isEnabled ?? false;
  if (!isEnabled) {
    await bluetooth.requestEnable();
  }

  List<BluetoothDevice> devices = await bluetooth.getBondedDevices();

  final hc06 = devices.firstWhere(
    (device) => device.name == "HC-06",
    orElse: () => throw Exception("HC-06 no emparejado"),
  );

  connection = await BluetoothConnection.toAddress(hc06.address);
  print('✅ Conectado a ${hc06.name}');

  connection!.input!.listen((Uint8List data) {
    print('📥 Recibido: ${String.fromCharCodes(data)}');
  });
}

void sendData(String message) {
  if (connection != null && connection!.isConnected) {
    connection!.output.add(Uint8List.fromList(message.codeUnits));
    connection!.output.allSent;
    print('📤 Enviado: $message');
  } else {
    print('⚠️ No estás conectado al HC-06');
  }
}
