import 'package:esqueleto_aplicacion_new/RutinasPage.dart';
import 'package:esqueleto_aplicacion_new/inicioPage.dart';
import 'package:flutter/material.dart';
import 'rutinasavanzadasPage.dart';
import 'comandos_bluetooth.dart'; // Asegurate de tener este archivo con la conexión

class Rutinas {
  // Lista de rutinas disponibles
  static const List<String> rutinasDisponibles = [
    'Rutina de Marcha',
    'Rutina de Piernas',
    'Rutina de Equilibrio',
    'Rehabilitación Avanzada++',
  ];

  // Método estático para obtener los íconos de las rutinas
  static List<String> obtenerIconosRutinas() {
    return [
      'assets/rut_marcha.png',
      'assets/rut_piernas.png',
      'assets/rut_equilibrio.png',
      'assets/rut_reha_avanzada.png',
    ];
  }

  // Método estático para obtener los textos de los botones
  static List<String> obtenerTextosBotones() {
    return [
      'Iniciar',
      'Iniciar',
      'Iniciar',
      '+++',
    ];
  }

  // Método estático para ejecutar una rutina específica
  static Future<void> ejecutarRutina(BuildContext context, int index) async {
    if (index < 0 || index >= rutinasDisponibles.length) return;

    try {
      await connectToHC06(); // Conexión Bluetooth antes de ejecutar la rutina
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Error al conectar: $e')),
      );
      return;
    }

    switch (index) {
      case 0:
        _ejecutarMarcha(context);
        break;
      case 1:
        _ejecutarPiernas(context);
        break;
      case 2:
        _ejecutarEquilibrio(context);
        break;
      case 3:
        _navegarARutinaAvanzada(context);
        break;
    }
  }

  static void ejecutarRutinaAvanzada(BuildContext context, int index) {
    if (index < 0 || index >= rutinasDisponibles.length) return;

    switch (index) {
      case 0:
        _ejecutarAvanzada1(context);
        break;
      case 1:
        _ejecutarAvanzada2(context);
        break;
      case 2:
        _ejecutarAvanzada3(context);
        break;
      case 3:
        _ejecutarAvanzada4(context);
        break;
    }
  }

  // Métodos privados para cada rutina específica
  static void _ejecutarMarcha(BuildContext context) {
    sendData("MARCHA");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Ejecutando: Rutina de Marcha')),
    );
  }

  static void _ejecutarPiernas(BuildContext context) {
    sendData("PIERNAS");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Ejecutando: Rutina de Piernas')),
    );
  }

  static void _ejecutarEquilibrio(BuildContext context) {
    sendData("EQUILIBRIO");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Ejecutando: Rutina de Equilibrio')),
    );
  }

  static void _ejecutarAvanzada1(BuildContext context) {
    sendData("AVANZADA1");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Avanzada 1')),
    );
  }

  static void _ejecutarAvanzada2(BuildContext context) {
    sendData("AVANZADA2");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Avanzada 2')),
    );
  }

  static void _ejecutarAvanzada3(BuildContext context) {
    sendData("AVANZADA3");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Avanzada 3')),
    );
  }

  static void _ejecutarAvanzada4(BuildContext context) {
    sendData("AVANZADA4");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🦾 Avanzada 4')),
    );
  }

  static void _navegarARutinaAvanzada(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => rutinasavanzadas(),
      ),
    );
  }

  static void navegarDesconectar(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => InicioPage(),
      ),
    );
  }

  static void navegarconectar(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => rutinasPage(),
      ),
    );
  }
}
